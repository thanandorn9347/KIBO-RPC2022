package jp.jaxa.iss.kibo.rpc.sampleapk;

import gov.nasa.arc.astrobee.Kinematics;
import gov.nasa.arc.astrobee.types.Point;
import gov.nasa.arc.astrobee.types.Quaternion;

public class LaserPoint {
    static Point pos_navcam_before_rotation_astrobee_frame = new Point(0.1177, -0.0422, -0.0826);
    static Point pos_laserpointer_before_rotation_astrobee_frame = new Point(0.1302, 0.0572, -0.1111);

    public static Quaternion_cal calcTargetQuaternion(Kinematics cur_kinematics, Point target_tvec_cam_frame) {
        Quaternion _cur_qua = cur_kinematics.getOrientation();
        Quaternion_cal cur_qua = new Quaternion_cal(_cur_qua.getX(), _cur_qua.getY(), _cur_qua.getZ(), _cur_qua.getW());
        Vector3_cal source_vector = new Vector3_cal(0, 0, 0);
        Point pos_target_navcam_frame = new Point(
                target_tvec_cam_frame.getZ(),
                target_tvec_cam_frame.getX(),
                target_tvec_cam_frame.getY());

        Point pos_target_before_rotation_astrobee_frame = new Point(
                pos_target_navcam_frame.getX() + pos_navcam_before_rotation_astrobee_frame.getX(),
                pos_target_navcam_frame.getY() + pos_navcam_before_rotation_astrobee_frame.getY(),
                pos_target_navcam_frame.getZ() + pos_navcam_before_rotation_astrobee_frame.getZ());

        Quaternion_cal pos_target_before_rotation_astrobee_frame_qua = new Quaternion_cal(
                (float) pos_target_before_rotation_astrobee_frame.getX(),
                (float) pos_target_before_rotation_astrobee_frame.getY(),
                (float) pos_target_before_rotation_astrobee_frame.getZ(),
                0);

        Quaternion_cal pos_target_after_rotation_astrobee_frame_quaternionCal = (cur_qua.times(pos_target_before_rotation_astrobee_frame_qua)).times(cur_qua.inverse());

        Vector3_cal target_after_rotation_astrobee_frame_vector = new Vector3_cal(
                pos_target_after_rotation_astrobee_frame_quaternionCal.getX(),
                pos_target_after_rotation_astrobee_frame_quaternionCal.getY(),
                pos_target_after_rotation_astrobee_frame_quaternionCal.getZ());
        Point cur_pos = cur_kinematics.getPosition();
//        Vector3_cal target_after_rotation_astrobee_frame_vector = new Vector3_cal(
//                11.2625-cur_pos.getX(),
//                -10.58-cur_pos.getY(),
//                5.3625-cur_pos.getZ());

        return Quaternion_cal.LookAt(source_vector, target_after_rotation_astrobee_frame_vector);
    }
    public static double[] calcTargetQuaternion_reverse(  Point cur_pos,Quaternion _cur_qua) {

        Quaternion_cal cur_qua = new Quaternion_cal(_cur_qua.getX(), _cur_qua.getY(), _cur_qua.getZ(), _cur_qua.getW());
        Vector3_cal target_after_rotation_astrobee_frame_vector = new Vector3_cal(
                11.2625-cur_pos.getX(),
                -10.58-cur_pos.getY(),
                5.3625-cur_pos.getZ());
        Quaternion_cal pos_target_after_rotation_astrobee_frame_quaternionCal = new Quaternion_cal(
                (float) target_after_rotation_astrobee_frame_vector.getX(),
                (float) target_after_rotation_astrobee_frame_vector.getY(),
                (float) target_after_rotation_astrobee_frame_vector.getZ(),
                0.f);
        Quaternion_cal pos_target_before_rotation_astrobee_frame_qua = (cur_qua.inverse().times(pos_target_after_rotation_astrobee_frame_quaternionCal)).times(cur_qua);
        Point pos_target_before_rotation_astrobee_frame = new Point(
                pos_target_before_rotation_astrobee_frame_qua.getX(),
                pos_target_before_rotation_astrobee_frame_qua.getY(),
                pos_target_before_rotation_astrobee_frame_qua.getZ());
        Point pos_target_navcam_frame = new Point(
                pos_target_before_rotation_astrobee_frame.getX() - pos_navcam_before_rotation_astrobee_frame.getX(),
                pos_target_before_rotation_astrobee_frame.getY() - pos_navcam_before_rotation_astrobee_frame.getY(),
                pos_target_before_rotation_astrobee_frame.getZ() - pos_navcam_before_rotation_astrobee_frame.getZ()
                );
        double[] target_tvec_cam_frame = {pos_target_navcam_frame.getY(),pos_target_navcam_frame.getZ(),pos_target_navcam_frame.getX()};
        return target_tvec_cam_frame;
    }

    public static Point calcTargetShootPosition(Kinematics kinematics, Quaternion_cal Ap_delta_quaternionCal) {
        Point Ap_pos = kinematics.getPosition();
        Quaternion_cal laserpointer_before_rotation_astrobee_frame = new Quaternion_cal(0.1302f, 0.0572f, -0.1111f, 0);
        Quaternion_cal laserpointer_after_rotation_astrobee_frame = (Ap_delta_quaternionCal.times(laserpointer_before_rotation_astrobee_frame)).times(Ap_delta_quaternionCal.inverse());

        return new Point(Ap_pos.getX() - laserpointer_after_rotation_astrobee_frame.getX(),
                Ap_pos.getY() - laserpointer_after_rotation_astrobee_frame.getY(),
                Ap_pos.getZ() - laserpointer_after_rotation_astrobee_frame.getZ());
    }

    public static Point calcTargetPositionRelative(Quaternion _cur_qua,  Point target_tvec_cam_frame) {

        Quaternion_cal cur_qua = new Quaternion_cal(_cur_qua.getX(), _cur_qua.getY(), _cur_qua.getZ(), _cur_qua.getW());

        Point pos_target_navcam_frame = new Point(
                target_tvec_cam_frame.getZ(),
                target_tvec_cam_frame.getX(),
                target_tvec_cam_frame.getY());

        Point pos_target_before_rotation_astrobee_frame = new Point(
                pos_target_navcam_frame.getX() + pos_navcam_before_rotation_astrobee_frame.getX(),
                pos_target_navcam_frame.getY() + pos_navcam_before_rotation_astrobee_frame.getY(),
                pos_target_navcam_frame.getZ() + pos_navcam_before_rotation_astrobee_frame.getZ());

        Quaternion_cal pos_target_before_rotation_astrobee_frame_qua = new Quaternion_cal(
                (float) pos_target_before_rotation_astrobee_frame.getX(),
                (float) pos_target_before_rotation_astrobee_frame.getY(),
                (float) pos_target_before_rotation_astrobee_frame.getZ(),
                0);

        Quaternion_cal pos_target_after_rotation_astrobee_frame_quaternionCal = (cur_qua.times(pos_target_before_rotation_astrobee_frame_qua)).times(cur_qua.inverse());

        Vector3_cal target_after_rotation_astrobee_frame_vector = new Vector3_cal(
                pos_target_after_rotation_astrobee_frame_quaternionCal.getX(),
                pos_target_after_rotation_astrobee_frame_quaternionCal.getY(),
                pos_target_after_rotation_astrobee_frame_quaternionCal.getZ());
        Point target_pos =  new Point(target_after_rotation_astrobee_frame_vector.getX(),target_after_rotation_astrobee_frame_vector.getY(),target_after_rotation_astrobee_frame_vector.getZ());
        return target_pos;
    }
}
