package jp.jaxa.iss.kibo.rpc.sampleapk;

import org.opencv.aruco.Aruco;
import org.opencv.aruco.Board;
import org.opencv.aruco.DetectorParameters;
import org.opencv.aruco.Dictionary;
import org.opencv.calib3d.Calib3d;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfDouble;
import org.opencv.core.MatOfInt;
import org.opencv.core.MatOfPoint;
import org.opencv.core.MatOfPoint2f;
import org.opencv.core.MatOfPoint3f;
import org.opencv.core.Point;
import org.opencv.core.Point3;
import org.opencv.core.Rect;
import org.opencv.imgproc.Imgproc;
import org.opencv.imgproc.Moments;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PoseEst {
    static ArBoard t_board1 = new ArBoard();
    static ArBoard t_board2 = new ArBoard();
    private static int dictID = Aruco.DICT_5X5_250;
    private static Mat ids;
    private static ArrayList<Mat> corners;
    private static Dictionary dict;
    private static CamParams camparams;
    private static Mat camMatrix;
    private static Mat dstMatrix;
    private static MatOfDouble distortion;
    private static double[] distortionArray;
    private static List<Mat> objP1;
    private static MatOfInt board1ID;
    private static List<Mat> objP2;
    private static MatOfInt board2ID;
    private static Mat t2_rvec;
    private static Mat t2_tvec;


    private static Mat read_img;
    public static Mat cropped_img;
    private static int cropped_x_pix;
    private static int cropped_y_pix;
    private static MatrixUtils matrixUtils;
    private static Point3 target_tvec_cam;
    private static void setCamCalibration(double[] _cameraMatrix, double[] _distCoeffs) {
        camparams = new CamParams(_cameraMatrix, _distCoeffs);
        camMatrix = camparams.getCamMatrix();
        dstMatrix = camparams.getDistortionMat();
        distortionArray = camparams.getDistortionArray();
        distortion = new MatOfDouble();
        distortion.fromArray(distortionArray);

    }

    private static void setBoard() {

        t_board1.set_target_board1();
        t_board2.set_target_board2();
        objP1 = t_board1.getObjP1();
        board1ID = t_board1.getBoard1ID();

        objP2 = t_board2.getObjP2();
        board2ID = t_board2.getBoard2ID();

    }

    private static void find_paper(List<Point> src_pts) {

        List<Integer> list_x = new ArrayList<Integer>();
        List<Integer> list_y = new ArrayList<Integer>();

        for (int i = 0; i < 4; i++) {
            list_x.add((int) src_pts.get(i).x);
            list_y.add((int) src_pts.get(i).y);
        }
        Collections.sort(list_x);
        Collections.sort(list_y);


//	    1-------0
//	    |		|
//	    |  x,y  |
//	    |		|
//	    2-------3

        MatOfPoint2f _pts = new MatOfPoint2f();
        _pts.fromList(src_pts);
        cropped_ROI(read_img, _pts);
    }

    private static void cropped_ROI(Mat img, MatOfPoint2f _pts) {
        Rect target_rect = Imgproc.boundingRect(_pts);
        cropped_img = new Mat();
        cropped_img = img.submat(target_rect);
        cropped_x_pix = target_rect.x;
        cropped_y_pix = target_rect.y;
        System.out.println("targetreact" + target_rect);
    }

    public static Point3 target2_poseEst(Mat _read_img, double[] _cameraMatrix, double[] _distCoeffs) {
        setCamCalibration(_cameraMatrix, _distCoeffs);
        setBoard();
        read_img = _read_img;
        corners = new ArrayList<>();
        ids = new Mat();

        dict = Aruco.getPredefinedDictionary(dictID);
        List<Mat> rejectedImg = new ArrayList<>();
        DetectorParameters parameters = DetectorParameters.create();
        ////////////////////////////////////////////////////
        Board t1_board = Board.create(objP1, dict, board1ID);
        Board t2_board = Board.create(objP2, dict, board2ID);
        ////////////////////////////////////////////////////
        Aruco.detectMarkers(read_img, dict, corners, ids,parameters,rejectedImg,camMatrix,dstMatrix);
        if (ids.empty()) {
            return null;
        }
        t2_rvec = new Mat();
        t2_tvec = new Mat();
        Aruco.estimatePoseBoard(corners, ids, t2_board, camMatrix, dstMatrix, t2_rvec, t2_tvec);
        double tvec_01 = t2_tvec.get(0, 0)[0];
        double tvec_02 = t2_tvec.get(1, 0)[0];
        double tvec_03 = t2_tvec.get(2, 0)[0];
        target_tvec_cam = new Point3(tvec_01,tvec_02,tvec_03);
        t_board2.find_ROI3D(t2_rvec, t2_tvec);
        List<MatOfPoint3f> offset = t_board2.get_offset();

        MatOfPoint2f _targetImagePlane = new MatOfPoint2f();
        Mat _rvec = new Mat(1, 3, CvType.CV_64FC1);
        Mat _tvec = new Mat(1, 3, CvType.CV_64FC1);

        double[] _r = new double[]{0.0f, 0.0f, 0.0f};
        double[] _t = new double[]{0.0f, 0.0f, 0.0f};
        _rvec.put(0, 0, _r);
        _tvec.put(0, 0, _t);

        List<Point> ROI_points = new ArrayList<Point>();

        for (int i = 0; i < 4; i++) {

            Calib3d.projectPoints(offset.get(i), _rvec, _tvec, camMatrix, distortion, _targetImagePlane);

            int _cpx = (int) _targetImagePlane.get(0, 0)[0];
            int _cpy = (int) _targetImagePlane.get(0, 0)[1];
            Point _center = new Point(_cpx, _cpy);
            System.out.println(offset.get(i).get(0, 0)[0] + " " + offset.get(i).get(0, 0)[1] + " "
                    + offset.get(i).get(0, 0)[2] + " ");
            System.out.println(_center);
            ROI_points.add(_center);
        }
        find_paper(ROI_points);


        List<MatOfPoint> contours = new ArrayList<>();
        Mat hierarchey = new Mat();
        Mat cropped_gray = new Mat();
//        Imgproc.cvtColor(cropped_img, cropped_gray, Imgproc.COLOR_BGR2GRAY);

        Mat binaryImg = new Mat();
        Imgproc.threshold(cropped_img, binaryImg, 100, 200, Imgproc.THRESH_BINARY_INV);

        Imgproc.findContours(binaryImg, contours, hierarchey, Imgproc.RETR_TREE, Imgproc.CHAIN_APPROX_NONE);

        for (int i = 0; i < contours.size(); i++) {

            if (hierarchey.get(0, i)[2] == -1.0) {
                MatOfPoint2f ct2f = new MatOfPoint2f(contours.get(i).toArray());
                Moments moment = Imgproc.moments(ct2f);

                int x = (int) (moment.get_m10() / moment.get_m00());
                int y = (int) (moment.get_m01() / moment.get_m00());
                MatOfPoint2f target_pos_pix = new MatOfPoint2f(new Point(x + cropped_x_pix, y + cropped_y_pix));

                MatOfPoint2f un_target_pos_pix = new MatOfPoint2f();
                Mat rot = new Mat();
                Calib3d.Rodrigues(t2_rvec, rot);
                Calib3d.undistortPoints(target_pos_pix, un_target_pos_pix, camMatrix, dstMatrix);
                System.out.println(un_target_pos_pix.dump());

                Mat rot_inverse = rot.inv();


                double[][] cam_minus_tran = {
                        new double[]{offset.get(0).get(0, 0)[0] - tvec_01},
                        new double[]{offset.get(0).get(0, 0)[1] - tvec_02},
                        new double[]{offset.get(0).get(0, 0)[2] - tvec_03},
                };
                double[][] rotationMatrix_inv = {new double[]{rot_inverse.get(0, 0)[0], rot_inverse.get(0, 1)[0], rot_inverse.get(0, 2)[0]},
                        new double[]{rot_inverse.get(1, 0)[0], rot_inverse.get(1, 1)[0], rot_inverse.get(1, 2)[0]},
                        new double[]{rot_inverse.get(2, 0)[0], rot_inverse.get(2, 1)[0], rot_inverse.get(2, 2)[0]}};
                matrixUtils = new MatrixUtils();
                double[][] world_coor = matrixUtils.multiplyMatrices(rotationMatrix_inv, cam_minus_tran);
                System.out.println("camminus" + cam_minus_tran[0][0] + " " + cam_minus_tran[1][0] + " "
                        + cam_minus_tran[2][0] + " ");
                System.out.println("worldcorr" + world_coor[0][0] + " " + world_coor[1][0] + " "
                        + world_coor[2][0] + " ");
                double rot_invere31 = rotationMatrix_inv[2][0];
                double rot_invere32 = rotationMatrix_inv[2][1];
                double rot_invere33 = rotationMatrix_inv[2][2];

                double z_c_numerator = rot_invere31 * tvec_01 + rot_invere32 * tvec_02 + rot_invere33 * tvec_03;
                double z_c_denomitor = (rot_invere31 * un_target_pos_pix.get(0, 0)[0]) + rot_invere32 * un_target_pos_pix.get(0, 0)[1] + rot_invere33;
                double z_c = z_c_numerator / z_c_denomitor;

                System.out.println("rot_inverse " + rot_inverse.dump());
                System.out.println("z_c" + z_c);
                MatOfPoint3f untarget_3d = new MatOfPoint3f(new Point3(un_target_pos_pix.get(0, 0)[0] * z_c, un_target_pos_pix.get(0, 0)[1] * z_c, z_c));



                System.out.println("un_target3d" + untarget_3d.dump());
                target_tvec_cam = untarget_3d.toArray()[0];


            }

        }
        return target_tvec_cam;

    }
}
