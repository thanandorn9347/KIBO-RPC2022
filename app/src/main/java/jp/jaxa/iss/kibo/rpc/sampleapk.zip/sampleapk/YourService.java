package jp.jaxa.iss.kibo.rpc.sampleapk;

import android.graphics.Bitmap;
import android.util.Log;

import gov.nasa.arc.astrobee.Kinematics;
import jp.jaxa.iss.kibo.rpc.api.KiboRpcService;

import gov.nasa.arc.astrobee.Result;
import gov.nasa.arc.astrobee.types.Point;
import gov.nasa.arc.astrobee.types.Quaternion;

import org.opencv.core.Mat;
import org.opencv.core.Point3;

/**
 * Class meant to handle commands from the Ground Data System and execute them in Astrobee
 */

public class YourService extends KiboRpcService {
    static Point pos_navcam = new Point(0.1177, -0.0422, -0.0826);
    static Point pos_laserpointer = new Point(0.1302, 0.0572, -0.1111);

    @Override
    protected void runPlan1() {
        // the mission starts

        api.startMission();
        double[][] camera_param = api.getNavCamIntrinsics();
        double[] cameraMatrix = camera_param[0];
        double[] distCoeffs = camera_param[1];
        System.out.println("cameraMatrix: " + cameraMatrix[0] + " " + cameraMatrix[1] + " " + cameraMatrix[2] + " " + cameraMatrix[3] + " " + cameraMatrix[4] + " " + cameraMatrix[5] + " " + cameraMatrix[6] + " " + cameraMatrix[7] + " " + cameraMatrix[8] + " ");
        System.out.println("distCoeffs: "+distCoeffs[0]+" "+distCoeffs[1]+" "+distCoeffs[2]+" "+distCoeffs[3]+" "+distCoeffs[4]+" ");
        // move to a point
        moveToWrapper(10.68 + 0.0285, -7.675 - 0.0994, 4.32, 0, 0.707, 0, 0.707);


        // report point1 arrival
        api.reportPoint1Arrival();

        // get a camera image

        // irradiate the laser
        api.laserControl(true);

        // take target1 snapshots
        api.takeTarget1Snapshot();
        Bitmap temp = api.getBitmapNavCam();
        api.saveBitmapImage(temp, "temp.jpg");

        // turn the laser off
        api.laserControl(false);

        /* ******************************************** */
        /* write your own code and repair the air leak! */
        /* ******************************************** */
        moveToWrapper(11.2, -9.44, 4.6, 0, 0, -0.707, 0.707);
        moveToWrapper(11.2625 - pos_navcam.getY(), -9.92284, 5.3625 - pos_navcam.getZ(), 0, 0, -0.7071068, 0.7071068);
        Mat image = api.getMatNavCam();


        Point point2_pos = new Point(11.2625 - pos_navcam.getY(),-9.92284,5.3625 - pos_navcam.getZ());
        Quaternion point2_quaternion = new Quaternion(0, 0, -0.7071068f, 0.7071068f);
        System.out.println("point2_pos: " + point2_pos.getX() + " " + point2_pos.getY() + " " + point2_pos.getZ());
        System.out.println("point2_quaternion: " + point2_quaternion.getX() + " " + point2_quaternion.getY() + " " + point2_quaternion.getZ() + " " + point2_quaternion.getW());
        double[] fixed_tar_pos = LaserPoint.calcTargetQuaternion_reverse(point2_pos,point2_quaternion);
        Point3 _target_tvec_cam_frame = PoseEst_fixed2.target2_poseEst(image, cameraMatrix, distCoeffs, fixed_tar_pos);
        Point target_tvec_cam_frame = new Point(_target_tvec_cam_frame.x, _target_tvec_cam_frame.y, _target_tvec_cam_frame.z);
        System.out.println("fixed_tar_pos: " + fixed_tar_pos[0] + " " + fixed_tar_pos[1] + " " + fixed_tar_pos[2]);
//        System.out.println("point2_kinematics: " + point2_kinematics.getConfidence());
        Quaternion_cal laser_quaternion_cal = new Quaternion_cal(0, 0, -0.7071068f, 0.7071068f);
        Point target_pos_rel = LaserPoint.calcTargetPositionRelative(point2_quaternion, target_tvec_cam_frame);
        moveToWrapper(point2_pos.getX() + target_pos_rel.getX() - pos_laserpointer.getY(),
                -10, point2_pos.getZ() + target_pos_rel.getZ() - pos_laserpointer.getZ(),
                laser_quaternion_cal.getX(), laser_quaternion_cal.getY(),
                laser_quaternion_cal.getZ(), laser_quaternion_cal.getW());
        api.laserControl(true);
        // take target2 snapshots
        api.takeTarget2Snapshot();

        // turn the laser off
        api.laserControl(false);
        // send mission completion
        api.saveMatImage(image, "point2");
        api.saveMatImage(PoseEst_fixed.cropped_img, "point2_cropped");
        moveToWrapper(11.0, -9.44, 5.2981, 0, 0, -0.707, 0.707);
        moveToWrapper(11.0, -8.0, 5.2981, 0, 0, -0.707, 0.707);
        moveToWrapper(11.27460, -7.89178, 4.96538, 0, 0, -0.707, 0.707);

        api.reportMissionCompletion();
    }

    @Override
    protected void runPlan2() {
        // write here your plan 2
    }

    @Override
    protected void runPlan3() {
        // write here your plan 3
    }

    // You can add your method
    private void moveToWrapper(double pos_x, double pos_y, double pos_z,
                               double qua_x, double qua_y, double qua_z,
                               double qua_w) {
        final int LOOP_MAX = 20;
        final Point point = new Point(pos_x, pos_y, pos_z);
        final Quaternion quaternion = new Quaternion((float) qua_x, (float) qua_y,
                (float) qua_z, (float) qua_w);

        Result result;
        int loopCounter = 0;
        do {
            result = api.moveTo(point, quaternion, true);
            if (result == null) {
                Log.d("moveToWrapper", "result==null");
                break;
            } else if (result.getMessage().contains("Keep out zone violation")) {
                Log.d("moveToWrapper", "result==KOZ");
                break;
            }

            ++loopCounter;

        } while (!result.hasSucceeded() && loopCounter < LOOP_MAX);
    }


    private void relativeMoveToWrapper(double pos_x, double pos_y, double pos_z,
                                       double qua_x, double qua_y, double qua_z,
                                       double qua_w) {

        final Point point = new Point(pos_x, pos_y, pos_z);
        final Quaternion quaternion = new Quaternion((float) qua_x, (float) qua_y,
                (float) qua_z, (float) qua_w);

        api.relativeMoveTo(point, quaternion, true);
    }

}

